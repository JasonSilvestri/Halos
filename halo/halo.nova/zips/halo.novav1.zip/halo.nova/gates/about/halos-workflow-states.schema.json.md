# About: `halos-workflow-states.schema.json`

**Kind:** schema  
**Path:** `gates/schemas/halos-workflow-states.schema.json`

---

## Purpose

JSON Schema used by Nova Halo v1.0.

---

## Preview

```
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "halos-workflow-states.schema.json",
  "title": "Halos Workflow State Mixin (Full 14-state + COMPLETED)",
  "type": "object",
  "required": [
    "state",
    "stateCode"
  ],
  "properties": {
    "stateCode": {
      "type": "integer",
      "enum": [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13,
        14,
        15
      ]
    },
    "state": {
      "type": "string",
      "enum": [
        "CREATED",
        "QUEUED",
        "IN_PROGRESS",
        "WAITING",
        "PASSED",
        "FAILED",
        "REJECTED",
        "CANCELLED",
        "SKIPPED",
        "TIMEOUT",
        "NETWORK_ERROR",
        "VALIDATION_ERROR",
        "RETRYING",
        "BLOCKED",
        "COMPLETED"
      ]
    },
    "updatedUtc": {
      "type": "string",
      "format": "date-time"
    },
    "reason": {
      "type": "string",
      "maxLength": 1000
    }
  },
  "allOf": [
    {
      "if": {
        "properties": {
          "state": {
            "const": "CREATED"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 1
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "QUEUED"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 2
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "IN_PROGRESS"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 3
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "WAITING"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 4
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "PASSED"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 5
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "FAILED"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 6
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "REJECTED"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 7
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "CANCELLED"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 8
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "SKIPPED"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 9
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "TIMEOUT"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 10
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "NETWORK_ERROR"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 11
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "VALIDATION_ERROR"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 12
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "RETRYING"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 13
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "BLOCKED"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 14
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "state": {
            "const": "COMPLETED"
          }
        },
        "required": [
          "state"
        ]
      },
      "then": {
        "properties": {
          "stateCode": {
            "const": 15
          }
        }
      }
    }
  ],
  "additionalProperties": true
}
```

---
